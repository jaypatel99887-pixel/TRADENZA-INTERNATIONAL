# Tradenza International Private Limited
### Official Global Import, Export, Sourcing & Trade Facilitation Corporate Platform

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new)

Official corporate website and B2B international sourcing platform for **Tradenza International Private Limited**, connecting global buyers with verified Indian manufacturers and suppliers.

---

## 🏢 Corporate Profile & Credentials

- **Company Name**: Tradenza International Private Limited
- **Business**: Global Import, Export, Sourcing & Trade Facilitation
- **Headquarters**: India
- **Email**: tradenzainternationalprivateli@gmail.com
- **Phone / WhatsApp**: +91 98251 15213
- **Active Trade Corridors**: UAE, Saudi Arabia, USA, UK, Europe, Africa, Southeast Asia, Nepal

---

## 🌐 Website Pages & Features

- **Homepage (/)**: Corporate overview, live buyer demand showcase, interactive trade map, and 4-step sourcing process.
- **Buyer Sourcing Board (/requirements)**: Live verified international buyer procurement demands across 12 sectors with real-time filters and quotation desks.
- **Sourcing Catalog (/products)**: 12 core Indian export product categories.
- **RFQ Sourcing Form (/rfq)**: Structured inquiry intake with port, quantity, and INCOTERMS.
- **Overseas Buyer Desk (/buyers)**: Dedicated portal for global importers and retail chains.
- **Indian Supplier Registration (/suppliers)**: Onboarding for domestic factories and millers.
- **Corporate About (/about)**: Story, values, and trade facilitation pillars.
- **Contact Desk (/contact)**: Official contact details and WhatsApp trade desk click-to-chat.
- **Admin Lead Portal (/admin)**: Internal lead review and status management.

---

## 🚀 How to Deploy on Vercel (100% Free & Fast)

### Method 1: Connect via GitHub (Automatic Updates)
1. Upload this repository to your GitHub account (e.g. 	radenza-website).
2. Go to [vercel.com](https://vercel.com) and log in.
3. Click **Add New...** &rarr; **Project**.
4. Select your **	radenza-website** GitHub repository.
5. In the configuration settings:
   - **Framework Preset**: Select **Other**
   - **Root Directory**: ./ (leave default)
   - **Build Command**: Leave empty
   - **Output Directory**: Leave empty
6. Click **Deploy**. Your site will be live on an official .vercel.app domain (and ready for your custom domain) in under 30 seconds!

### Method 2: Deploy directly via Vercel CLI
`ash
npm i -g vercel
vercel
`

---

## 📁 Repository Structure
`
├── index.html             # Homepage
├── requirements.html      # Public Buyer Sourcing Board
├── products.html          # Sourcing Catalog
├── rfq.html               # RFQ Intake Form
├── buyers.html            # International Buyer Desk
├── suppliers.html         # Indian Supplier Registration
├── about.html             # Corporate About
├── contact.html           # Contact Desk
├── admin.html             # Lead Management Portal
├── 404.html               # Custom 404 Error Page
├── vercel.json            # Vercel cleanUrls & cache configuration
├── static/                # CSS, JavaScript, and Brand Images
└── api/                   # Public JSON API endpoints
`
