/**
 * Vercel Serverless Function: POST /api/contact
 * Handles contact desk messages and delivers to Tradenza International corporate inbox.
 */
module.exports = async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Accept');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ success: false, message: 'Method Not Allowed' });
  }

  try {
    const data = typeof req.body === 'string' ? JSON.parse(req.body) : (req.body || {});

    try {
      await fetch('https://formsubmit.co/ajax/info@tradenza-international.com', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          _subject: `New Contact Message: ${data.subject || 'Trade Inquiry'} - ${data.name}`,
          _template: 'table',
          _captcha: 'false',
          form_type: 'Contact Inquiry',
          contact_name: data.name,
          company: data.company || 'N/A',
          country: data.country || 'N/A',
          email: data.email,
          phone_whatsapp: data.phone || 'N/A',
          subject: data.subject || 'General Trade Inquiry',
          message: data.message,
          submitted_at: new Date().toISOString()
        })
      });
    } catch (e) {
      console.error('Email gateway dispatch error:', e);
    }

    return res.status(200).json({
      success: true,
      id: Date.now(),
      message: 'Thank you for reaching out. A Tradenza representative will reply to your message shortly.'
    });
  } catch (err) {
    console.error('Serverless Contact Error:', err);
    return res.status(500).json({ success: false, message: 'Server error processing contact message' });
  }
};
