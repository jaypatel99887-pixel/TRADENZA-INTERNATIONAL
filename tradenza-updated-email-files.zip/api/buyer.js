/**
 * Vercel Serverless Function: POST /api/buyer
 * Handles international buyer requirements and forwards to Tradenza trade desk.
 */
module.exports = async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Accept');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ success: false, message: 'Method Not Allowed' });
  }

  try {
    const data = typeof req.body === 'string' ? JSON.parse(req.body) : (req.body || {});

    try {
      await fetch('https://formsubmit.co/ajax/info@tradenza-international.com', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          _subject: `New Buyer Requirement: ${data.product || 'Demand'} - ${data.company || data.name}`,
          _template: 'table',
          _captcha: 'false',
          form_type: 'Buyer Procurement Lead',
          buyer_name: data.name,
          company: data.company || 'N/A',
          country: data.country || 'N/A',
          email: data.email,
          phone_whatsapp: data.phone,
          product_name: data.product,
          quantity: data.quantity || 'N/A',
          target_price: data.target_price || 'N/A',
          destination_country_port: data.destination_country || 'N/A',
          notes: data.message || 'N/A',
          submitted_at: new Date().toISOString()
        })
      });
    } catch (e) {
      console.error('Email gateway dispatch error:', e);
    }

    return res.status(200).json({
      success: true,
      id: Date.now(),
      message: 'Your buyer requirement has been registered. The Tradenza International team will review and match suitable Indian producers.'
    });
  } catch (err) {
    console.error('Serverless Buyer Error:', err);
    return res.status(500).json({ success: false, message: 'Server error processing buyer requirement' });
  }
};
