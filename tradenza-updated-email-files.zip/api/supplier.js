/**
 * Vercel Serverless Function: POST /api/supplier
 * Handles supplier registrations & responses to sourcing demands.
 */
module.exports = async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Accept');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ success: false, message: 'Method Not Allowed' });
  }

  try {
    const data = typeof req.body === 'string' ? JSON.parse(req.body) : (req.body || {});

    try {
      await fetch('https://formsubmit.co/ajax/info@tradenza-international.com', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          _subject: `New Supplier Application / Lead Response: ${data.company || data.name} - ${data.products || data.product || 'Capacity'}`,
          _template: 'table',
          _captcha: 'false',
          form_type: 'Supplier Application',
          requirement_ref: data.requirement_id ? `#TRQ-${data.requirement_id}` : 'General Registration',
          supplier_name: data.name,
          company: data.company,
          email: data.email,
          phone_whatsapp: data.phone,
          product_category: data.product_category || 'N/A',
          products: data.products || data.product || 'N/A',
          location: data.location || 'India',
          manufacturing_capacity: data.manufacturing_capacity || 'N/A',
          export_experience: data.export_experience || 'N/A',
          website: data.website || 'N/A',
          quotation_notes: data.message || 'N/A',
          submitted_at: new Date().toISOString()
        })
      });
    } catch (e) {
      console.error('Email gateway dispatch error:', e);
    }

    return res.status(200).json({
      success: true,
      id: Date.now(),
      message: 'Your supplier registration / supply proposal has been received. Our trade desk will review your manufacturing capability.'
    });
  } catch (err) {
    console.error('Serverless Supplier Error:', err);
    return res.status(500).json({ success: false, message: 'Server error processing supplier application' });
  }
};
