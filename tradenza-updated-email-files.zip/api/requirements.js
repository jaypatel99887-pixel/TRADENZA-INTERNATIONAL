/**
 * Vercel Serverless Function: GET & POST /api/requirements
 * Returns public requirements or accepts new buyer demand postings.
 */
const initialRequirements = [
  {
    "id": 1,
    "ref_code": "TRQ-1048",
    "product_name": "Premium Indian Basmati Rice (1121 Steam & Parboiled)",
    "category": "Rice & Grains",
    "country": "United Arab Emirates",
    "country_flag": "\uD83C\uDDE6\uD83C\uDDE9",
    "destination_port": "Port of Jebel Ali, Dubai",
    "quantity": "500 Metric Tons (20x40ft FCL)",
    "target_price": "Competitive CIF Jebel Ali",
    "specifications": "Average grain length 8.35mm+, moisture max 12.5%, purity 95%, sortex clean, silky polished",
    "packaging": "50kg non-woven master bags with inner poly liner",
    "timeline": "Within 30 days of LC confirmation",
    "buyer_type": "Supermarket Distribution Chain",
    "status": "Active Sourcing",
    "is_featured": 1
  },
  {
    "id": 2,
    "ref_code": "TRQ-1049",
    "product_name": "Polished Vitrified Floor & Wall Tiles (600x1200mm)",
    "category": "Tiles & Building Materials",
    "country": "United Kingdom",
    "country_flag": "\uD83C\uDDEC\uD83C\uDDE7",
    "destination_port": "Port of Felixstowe",
    "quantity": "4x40ft Containers Monthly",
    "target_price": "FOB Mundra",
    "specifications": "Porcelain body, polished nano finish, water absorption < 0.05%, rectified edges, grade AAA",
    "packaging": "Export wooden pallet packing with protective corner guards & shrink film",
    "timeline": "Monthly recurring contract",
    "buyer_type": "UK Building Materials Distributor",
    "status": "Shortlisting Indian Suppliers",
    "is_featured": 1
  },
  {
    "id": 3,
    "ref_code": "TRQ-1050",
    "product_name": "Machine Cleaned Whole Spices (Cumin & Turmeric)",
    "category": "Spices",
    "country": "Saudi Arabia",
    "country_flag": "\uD83C\uDDF8\uD83C\uDDE6",
    "destination_port": "Jeddah Islamic Port",
    "quantity": "54 Metric Tons (2x40ft FCL)",
    "target_price": "Target CIF Jeddah",
    "specifications": "Cumin seeds 99% purity machine cleaned, Turmeric finger curcumin > 3.5%, phytosanitary ready",
    "packaging": "25kg food-grade PP bags with moisture barrier liner",
    "timeline": "Within 25 days",
    "buyer_type": "Saudi Wholesale Food Consortia",
    "status": "Verified Demand",
    "is_featured": 1
  },
  {
    "id": 4,
    "ref_code": "TRQ-1051",
    "product_name": "100% Combed Cotton Knitted T-Shirts & Polos",
    "category": "Textiles & Garments",
    "country": "United States",
    "country_flag": "\uD83C\uDDFA\uD83C\uDDF8",
    "destination_port": "Port of Newark / New York",
    "quantity": "25,000 Pieces",
    "target_price": "Target FOB Tuticorin / Nhava Sheva",
    "specifications": "180 GSM bio-washed 100% combed ringspun cotton, reactive dyed, OEKO-TEX certified, custom neck labels",
    "packaging": "Individual polybag, 50 pcs per export master carton with barcode stickers",
    "timeline": "Within 60 days",
    "buyer_type": "US Private Label Apparel Importer",
    "status": "Active Sourcing",
    "is_featured": 1
  },
  {
    "id": 5,
    "ref_code": "TRQ-1052",
    "product_name": "Industrial Cast Iron & Stainless Steel Gate Valves",
    "category": "Industrial Products",
    "country": "Germany",
    "country_flag": "\uD83C\uDDE9\uD83C\uDDEA",
    "destination_port": "Port of Hamburg",
    "quantity": "5,000 Units",
    "target_price": "FOB Nhava Sheva",
    "specifications": "Class 150 & 300, Flanged ends according to ANSI B16.5, hydrostatic tested with mill test certs",
    "packaging": "Fumigated wooden cases with corrosion inhibitor wrap and desiccants",
    "timeline": "Within 45 days",
    "buyer_type": "European Pipeline & Industrial Supply Group",
    "status": "Shortlisting Indian Suppliers",
    "is_featured": 1
  },
  {
    "id": 6,
    "ref_code": "TRQ-1053",
    "product_name": "Fresh Indian Cavendish Bananas (G9 Variety)",
    "category": "Fruits & Vegetables",
    "country": "Oman",
    "country_flag": "\uD83C\uDDF4\uD83C\uDDF2",
    "destination_port": "Port Sultan Qaboos / Sohar",
    "quantity": "2x40ft High Cube Reefer Containers (Weekly)",
    "target_price": "CIF Sohar",
    "specifications": "Length min 7.5 inches, calibration 39-47, pre-cooled, temperature controlled at 13.5°C in reefer",
    "packaging": "13.5kg corrugated telescopic boxes with vacuum polybags & foam separator sheets",
    "timeline": "Immediate recurring weekly supply",
    "buyer_type": "Gulf Fresh Produce Hypermarket Chain",
    "status": "Active Sourcing",
    "is_featured": 1
  },
  {
    "id": 7,
    "ref_code": "TRQ-1054",
    "product_name": "Nitrile Examination Gloves & Medical Disposables",
    "category": "Medical & Healthcare Supplies",
    "country": "France",
    "country_flag": "\uD83C\uDDE8\uD83C\uDDF7",
    "destination_port": "Port of Le Havre",
    "quantity": "200,000 Pairs (Pilot Consignment)",
    "target_price": "CIF Le Havre",
    "specifications": "Powder-free, blue medical nitrile, EN455 Class 1, ISO 13485 & CE certified, non-sterile",
    "packaging": "100 pcs dispenser box, 10 dispenser boxes per master shipping carton",
    "timeline": "Within 30 days",
    "buyer_type": "European Healthcare Procurement Group",
    "status": "Verified Demand",
    "is_featured": 1
  },
  {
    "id": 8,
    "ref_code": "TRQ-1055",
    "product_name": "Corrugated Shipping Master Cartons & FIBC Bags",
    "category": "Packaging Products",
    "country": "Netherlands",
    "country_flag": "\uD83C\uDDF3\uD83C\uDDF1",
    "destination_port": "Port of Rotterdam",
    "quantity": "50,000 Master Cartons + 2,000 Bulk Bags",
    "target_price": "CIF Rotterdam",
    "specifications": "5-ply kraft board, burst strength 14 kg/cm², UV stabilized FIBC bulk bags 1,000kg safe working load",
    "packaging": "Strapped bundles on ISPM-15 treated heat-treated wooden pallets",
    "timeline": "Within 40 days",
    "buyer_type": "Agri-Commodity Logistics Provider",
    "status": "Active Sourcing",
    "is_featured": 1
  },
  {
    "id": 9,
    "ref_code": "TRQ-1056",
    "product_name": "Handcrafted Brass Artware & Metal Table Décor",
    "category": "Home & Lifestyle Products",
    "country": "Canada",
    "country_flag": "\uD83C\uDDE8\uD83C\uDDE6",
    "destination_port": "Port of Vancouver",
    "quantity": "1x20ft Container (Assorted SKU Mix)",
    "target_price": "FOB Mundra",
    "specifications": "Lacquered polished brass planters, candle stands, embossed bowls, and metal serving trays",
    "packaging": "Individual bubble-wrapped inner gift boxes with 5-ply master export cartons",
    "timeline": "Within 60 days",
    "buyer_type": "North American Home Goods Retailer",
    "status": "Shortlisting Indian Suppliers",
    "is_featured": 0
  },
  {
    "id": 10,
    "ref_code": "TRQ-1057",
    "product_name": "Non-GMO Soya Meal & Animal Feed Pellets",
    "category": "Agricultural Products",
    "country": "Vietnam",
    "country_flag": "\uD83C\uDDF8\uD83C\uDDF3",
    "destination_port": "Hai Phong Port",
    "quantity": "1,500 Metric Tons",
    "target_price": "CIF Hai Phong",
    "specifications": "Crude protein min 48%, moisture max 11%, fiber max 6%, non-GMO certified with test certificate",
    "packaging": "Bulk in 1,000kg PP jumbo tote bags with lifting loops",
    "timeline": "Within 35 days",
    "buyer_type": "Southeast Asian Feed Mill Enterprise",
    "status": "Active Sourcing",
    "is_featured": 0
  },
  {
    "id": 11,
    "ref_code": "TRQ-1058",
    "product_name": "Chakki Whole Wheat Flour & Sella Non-Basmati Rice",
    "category": "Food & Beverages",
    "country": "Nepal",
    "country_flag": "\uD83C\uDDF3\uD83C\uDDF5",
    "destination_port": "Birgunj Dry Port (Overland Transit)",
    "quantity": "300 Metric Tons",
    "target_price": "CPT Birgunj",
    "specifications": "100% stone ground whole wheat atta, high gluten, Sella non-basmati rice 5% broken max",
    "packaging": "25kg and 50kg HDPE woven bags with inner poly liner",
    "timeline": "Within 14 days",
    "buyer_type": "Regional Food Distribution Network",
    "status": "Verified Demand",
    "is_featured": 0
  },
  {
    "id": 12,
    "ref_code": "TRQ-1059",
    "product_name": "Ceramic Sanitaryware & Vitreous China Water Closets",
    "category": "Tiles & Building Materials",
    "country": "Kenya",
    "country_flag": "\uD83C\uDDF0\uD83C\uDDEA",
    "destination_port": "Port of Mombasa",
    "quantity": "2x40ft Containers",
    "target_price": "CIF Mombasa",
    "specifications": "Dual flush rimless one-piece water closets, vitreous china body, soft-close seat covers, wash basins",
    "packaging": "5-ply foam-protected individual cartons, palletized for container loading",
    "timeline": "Within 45 days",
    "buyer_type": "East African Hardware & Plumbing Importer",
    "status": "Active Sourcing",
    "is_featured": 0
  }
];

module.exports = async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Accept');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method === 'GET') {
    const { category, search } = req.query || {};
    let filtered = initialRequirements;

    if (category && category !== 'all') {
      filtered = filtered.filter(item => (item.category || '').toLowerCase() === category.toLowerCase());
    }

    if (search) {
      const q = search.toLowerCase();
      filtered = filtered.filter(item =>
        (item.product_name || '').toLowerCase().includes(q) ||
        (item.category || '').toLowerCase().includes(q) ||
        (item.country || '').toLowerCase().includes(q) ||
        (item.destination_port || '').toLowerCase().includes(q) ||
        (item.specifications || '').toLowerCase().includes(q)
      );
    }

    return res.status(200).json({
      success: true,
      count: filtered.length,
      items: filtered
    });
  }

  if (req.method === 'POST') {
    try {
      const data = typeof req.body === 'string' ? JSON.parse(req.body) : (req.body || {});

      try {
        await fetch('https://formsubmit.co/ajax/info@tradenza-international.com', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          },
          body: JSON.stringify({
            _subject: `New Sourcing Requirement Posted: ${data.product || 'Demand'} from ${data.company || data.name}`,
            _template: 'table',
            _captcha: 'false',
            form_type: 'Public Sourcing Requirement Post',
            ...data,
            submitted_at: new Date().toISOString()
          })
        });
      } catch (e) {
        console.error('Email gateway dispatch error:', e);
      }

      return res.status(200).json({
        success: true,
        id: Date.now(),
        message: 'Your sourcing requirement has been posted to Tradenza International trade desk.'
      });
    } catch (err) {
      return res.status(500).json({ success: false, message: 'Server error processing requirement' });
    }
  }

  return res.status(405).json({ success: false, message: 'Method Not Allowed' });
};
