/**
 * Vercel Serverless Function: POST /api/rfq
 * Handles incoming RFQs and forwards directly to Tradenza International's trade desk.
 */
module.exports = async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Accept');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ success: false, message: 'Method Not Allowed' });
  }

  try {
    const data = typeof req.body === 'string' ? JSON.parse(req.body) : (req.body || {});

    // Forward to Tradenza International corporate email gateway
    try {
      await fetch('https://formsubmit.co/ajax/info@tradenza-international.com', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          _subject: `New Sourcing RFQ: ${data.product || 'Trade Requirement'} - ${data.company || data.name}`,
          _template: 'table',
          _captcha: 'false',
          form_type: 'RFQ Submission',
          buyer_name: data.name,
          company: data.company || 'N/A',
          email: data.email,
          phone_whatsapp: data.phone,
          product_category: data.product_category || 'General',
          product_name: data.product,
          quantity: data.quantity || 'N/A',
          destination_country_port: data.destination_country || 'N/A',
          specifications: data.specifications || 'N/A',
          packaging: data.packaging || 'N/A',
          delivery_timeline: data.delivery_timeline || 'N/A',
          notes: data.message || 'N/A',
          submitted_at: new Date().toISOString()
        })
      });
    } catch (emailErr) {
      console.error('Email gateway dispatch error:', emailErr);
    }

    return res.status(200).json({
      success: true,
      id: Date.now(),
      message: 'Your requirement has been received by Tradenza International Private Limited. Our trade desk will review your specifications and contact you shortly.'
    });
  } catch (err) {
    console.error('Serverless RFQ Error:', err);
    return res.status(500).json({ success: false, message: 'Server error processing requirement' });
  }
};
